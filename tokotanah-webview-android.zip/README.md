# Toko Tanah Android WebView

Android WebView wrapper untuk **Toko Tanah**.

- URL: `https://tokotanah.thegreatmonolith.com`
- Application ID: `com.thegreatmonolith.tokotanah`
- Min SDK: 23
- Target / Compile SDK: 36 (Android 16)
- Java: 17
- Splash: **1 splash native saja**, durasi ±1.5 detik
- Splash background: `#7A4C2F` (warna dominan logo Toko Tanah)
- Logo splash: logo Toko Tanah putih di tengah
- Mendukung file upload, kamera, lokasi, download, cookies/session, deep link domain Toko Tanah, dan tombol Back WebView

## Build lokal

Gunakan Android Studio terbaru (recommended), atau JDK 17 + Android SDK API 36 + Gradle 8.13.

```bash
gradle assembleDebug
```

Debug APK:

`app/build/outputs/apk/debug/app-debug.apk`

## Signing AAB untuk Play Store

### 1. Buat upload keystore sekali saja

Linux/macOS/Git Bash:

```bash
./scripts/generate-upload-keystore.sh tokotanah-upload.jks tokotanah
```

Atau langsung:

```bash
keytool -genkeypair -v -keystore tokotanah-upload.jks -alias tokotanah -keyalg RSA -keysize 2048 -validity 10000
```

**Simpan file JKS dan password secara permanen. Jangan commit ke repository.**

### 2. Ubah JKS menjadi Base64

Linux:

```bash
base64 -w 0 tokotanah-upload.jks > keystore-base64.txt
```

macOS:

```bash
base64 -i tokotanah-upload.jks | tr -d '\n' > keystore-base64.txt
```

Windows PowerShell:

```powershell
[IO.File]::WriteAllText("keystore-base64.txt", [Convert]::ToBase64String([IO.File]::ReadAllBytes("tokotanah-upload.jks")))
```

### 3. Tambahkan GitHub Actions Secrets

Repository GitHub → **Settings → Secrets and variables → Actions → New repository secret**.

Tambahkan 4 secret:

- `ANDROID_KEYSTORE_BASE64` = seluruh isi `keystore-base64.txt`
- `ANDROID_KEYSTORE_PASSWORD` = password keystore
- `ANDROID_KEY_ALIAS` = `tokotanah` (atau alias yang Anda pilih)
- `ANDROID_KEY_PASSWORD` = password key/alias

### 4. Build melalui GitHub

Workflow: `.github/workflows/android-build.yml`

Workflow menyiapkan Gradle 8.13 secara otomatis, jadi repository tidak bergantung pada Gradle yang terpasang di runner.

Bisa dijalankan dari **Actions → Android Build → Run workflow**. Workflow juga berjalan saat push ke branch `main`.

Artifact hasil build:

- `tokotanah-debug-apk` → APK debug untuk pengujian
- `tokotanah-playstore-aab` → AAB release yang sudah ditandatangani untuk Google Play

`versionCode` otomatis menggunakan nomor GitHub Actions run sehingga naik setiap build. `versionName` otomatis menjadi `1.0.<run_number>`.

## Build signed AAB secara lokal

Buat `keystore.properties` di root project:

```properties
storeFile=tokotanah-upload.jks
storePassword=PASSWORD_KEYSTORE
keyAlias=tokotanah
keyPassword=PASSWORD_KEY
```

Lalu:

```bash
gradle bundleRelease
```

Hasil:

`app/build/outputs/bundle/release/app-release.aab`

## Catatan Play Store

Project menggunakan target SDK 36 sesuai persyaratan aplikasi baru/update Google Play mulai 31 Agustus 2026.

Permission kamera dan lokasi hanya diminta ketika fitur website membutuhkannya. Download memakai DownloadManager Android. HTTP cleartext dinonaktifkan; aplikasi hanya memuat koneksi HTTPS.

## Mengganti URL / package name

- URL utama: `app/src/main/res/values/strings.xml` → `web_url`
- Host internal: `MainActivity.java` → `APP_HOST`
- Application ID: `app/build.gradle` → `applicationId`
- Package Java: folder dan deklarasi package `com.thegreatmonolith.tokotanah`

**Penting:** setelah aplikasi pertama kali dipublikasikan di Google Play, jangan mengganti `applicationId` untuk update berikutnya.

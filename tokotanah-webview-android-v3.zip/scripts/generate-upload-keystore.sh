#!/usr/bin/env bash
set -euo pipefail

KEYSTORE_FILE="${1:-tokotanah-upload.jks}"
KEY_ALIAS="${2:-tokotanah}"

keytool -genkeypair -v \
  -keystore "$KEYSTORE_FILE" \
  -alias "$KEY_ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

echo
echo "Keystore created: $KEYSTORE_FILE"
echo "Alias: $KEY_ALIAS"
echo "Keep this keystore and its passwords permanently. Do not commit it to Git."
